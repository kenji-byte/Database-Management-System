package classes ;
import interfaces .* ;

import java.lang.* ;

public class Customer implements BusOperations
{
	private String customerName;
	private int customerId;
	private Bus Ticket[]=new Bus[10];

	
	public void setCustomerName(String customerName)
	{
		this.customerName=customerName;
	}
	
	public void setCustomerId(int customerId)
	{
		this.customerId=customerId;
	}
	
	public String getCustomerName()
	{
		return customerName;
	}
	
	public int getCustomerId()
	{
		return customerId;
	}
	
	public void bookTicket(Bus b)
	{
		int bb=0;
		for(int i=0; i< Ticket.length; i++)
		{
			if( Ticket[i]==null)
			{
				 Ticket[i]=b;
				bb=1;
				break;
			}
		}
		if(bb==1)
		{
			System.out.println("The Ticket is booked.");
		}
		else {
			System.out.println("The Ticket is not booked.");
		}
	}
	
	
	public void cancelTicket(Bus b)
	{
		int bb=0;
		for(int i=0; i<Ticket.length; i++)
		{
			if(Ticket[i] == b)
			{
				Ticket[i]=null;
				bb=1;
				break;
			}
		}
		if(bb==1)
		{
			System.out.println("The Ticket is cancelled.");
		}
		else{
			System.out.println("The Ticket is not  cancelled.");
		}
	}
	
	public Bus getTicket(int BusId)
	{
		Bus b = null;
		
		for(int i=0; i<Ticket.length; i++)
		{
			if(Ticket[i] != null)
			{
				if(Ticket[i].getBusId() == BusId)
				{
					b = Ticket[i];
					break;
				}
			}
		}
		if(b != null)
		{
			System.out.println("Ticket Found");
		}
		else
		{
			System.out.println("Ticket Not Found");
		}
		return b;
	}
	
	public void searchTicket(Bus b)
	{
		int bb=0;
		for(int i=0; i< Ticket.length; i++)
		{
		
			if( Ticket[i] == b)
			{
				 Ticket[i]=null;
				bb=1;
				break;
			}
		}
		if(bb==1)
		{
			System.out.println(" Searching Complete .");
		}
		else{
			System.out.println("  Searching not Complete.");
		}
	}
	
	public void showAllTicket()
	{
		for( Bus b : Ticket)
			if(b != null)
			{
				b.showBusDetails();
			}
	}

	public void showAlBuss() {
	}

    public void showAlBus() {
    }
}
	
	
