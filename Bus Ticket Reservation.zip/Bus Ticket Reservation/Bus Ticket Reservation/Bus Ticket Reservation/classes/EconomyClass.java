package classes;

import java.lang.* ;

public class EconomyClass extends Bus
{
	
	
	public void showBusDetails()
	{
		System.out.println("---------------------------");
		System.out.println("|   Economy Class        |");
		System.out.println("---------------------------");
		System.out.println("Type Of Bus:"+getTypeOfBus());
		System.out.println("Bus ID:"+getBusId());
		System.out.println("Bus Name:"+getBusName());
		System.out.println("Bus Source:"+getSource());
		System.out.println("Bus Destination:"+getDestination());
		System.out.println("Date:"+getDate());
		System.out.println("Arrival Time:"+getArrivalTime());
		System.out.println("Departure Time:"+getDepartureTime());
		System.out.println("Ticket Price:"+getTicketPrice());
		System.out.println("Ticket Available Quantity:"+getTicketAvailableQuantity());
		
	}

	private String getTypeOfBus() {
		return null;
	}

    public void setTypeOfBus(String typeOfBus) {
    }
}