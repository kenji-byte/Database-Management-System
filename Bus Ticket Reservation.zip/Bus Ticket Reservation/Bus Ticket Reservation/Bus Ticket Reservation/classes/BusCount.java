package classes;

import interfaces .* ;

import java.lang.* ;

public class BusCount implements  CustomerOperations, BusTicketOperations
{
	
	private Customer customers[]=new Customer[10];
	private BusTicket tickets[]=new BusTicket[10];
	
	
	
	public BusCount( ) { }
	
		
	public void insertCustomer(Customer c)
	{
		int flag = 0;
		for(int i=0; i<customers.length; i++)
		{
			if(customers[i] == null)
			{
				customers[i] = c;
				flag = 1;
				break;
			}
		}
		if(flag == 1)
		{
			System.out.println("Customer Inserted");
		}
		else
		{
			System.out.println("Can Not Insert");
		}
	}
	
	public void removeCustomer(Customer c)
	{
		int flag = 0;
		for(int i=0; i<customers.length; i++)
		{
			if(customers[i] == c)
			{
				customers[i] = null;
				flag = 1;
				break;
			}
		}
		if(flag == 1){System.out.println("Customer Removed");}
		else{System.out.println("Can Not Remove");}
	}
	public void showAllCustomers()
	{
		for(Customer c : customers)
		{
			if(c != null)
			{
				System.out.println("**********************************");
				System.out.println("Customer Name: "+ c.getCustomerName());
				System.out.println("Customer NID: "+ c.getCustomerId());
				System.out.println("----------------------------------");
				c.showAllTicket();
				System.out.println("----------------------------------");
			}
		}
	}
	
	public Customer getCustomer(int customerId)
	{
		Customer c = null;
		
		for(int i=0; i<customers.length; i++)
		{
			if(customers[i] != null)
			{
				if(customers[i].getCustomerId() ==customerId)
				{
					c = customers[i];
					break;
				}
			}
		}
		if(c != null)
		{
			System.out.println("Customer Found");
		}
		else
		{
			System.out.println("Customer Not Found");
		}
		return c;
	}
	
	
				// Bus Ticket///
	public void addTicket( BusTicket t)
	{
		int flag=0;
		for(int i=0; i<tickets.length; i++)
		{
			if(tickets[i]==null)
			{
				tickets[i]=t;
				flag=1;
				break;
			}
		}
		if(flag==1)
		{
			System.out.println("The Bus ticket is added");
		}
		else {
			System.out.println("The  Bus ticket is not added");
		}
	}
	
	public void cancelTicket (Object object)
	{
		int flag=0;
		for(int i=0; i<tickets.length; i++)
		{
			
			if(tickets[i] == object)
			{
				tickets[i]=null;
				flag=1;
				break;
			}
		}
		if(flag==1)
		{
			System.out.println("The Bus ticket  is deleted.");
		}
		else{
			System.out.println("The Bus ticket is not deleted.");
		}
	}
	
	public BusTicket getTicket(int BusId)
	{
	 BusTicket t = null;
		
		for(int i=0; i<tickets.length; i++)
		{
			if(tickets[i] != null)
			{
				if(tickets[i].getBusId() == BusId)
				{
					t = tickets[i];
					break;
				}
			}
		}
		if(t != null)
		{
			System.out.println( "Bus ticket Found");
		}
		else
		{
			System.out.println( "Busticket Not Found");
		}
		return t;
	}
	
	public void showAlBusTickets()
	{
		System.out.println("//////////////////////////////////");
		for (BusTicket t : tickets)
		{
			if(t != null)
			{
				System.out.println("Type Of Bus:"+t.getTypeOfBus());
				System.out.println( "BusID:"+t.getBusId());
				System.out.println( "Bus Name:"+t.getBusName());
				System.out.println( "Bus Source:"+t.getSource());
				System.out.println(" Bus Destination:"+t.getDestination());
				System.out.println("Date:"+t.getDate());
				System.out.println("Arrival Time:"+t.getArrivalTime());
				System.out.println("Departure Time:"+t.getDepartureTime());
				System.out.println("Ticket Price:"+t.getTicketPrice());
				System.out.println("Ticket Available Quantity:"+t.getTicketAvailableQuantity());
			}


				


				}




				
				
		}
		
	


	@Override
	public void addBusTicket(BusTicket t) {
		// TODO Auto-generated method stub
		
	}


	@Override
	public void deleteBusTicket(BusTicket t) {
		// TODO Auto-generated method stub
		
	}


	@Override
	public BusTicket getBusTicket(int BusId) {
		// TODO Auto-generated method stub
		return null;
	}





	@Override
	public void showAllBusTickets() {
		// TODO Auto-generated method stub
		
	}


	


   
	}
	
	
	
