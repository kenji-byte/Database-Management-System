package  classes;
import java.lang.*;

public class BusTicket 
{
	private String typeOfBus;
	private int BusId;
	private String BusName;
	private String source;
	private String destination;
	private String date;
	private String arrivalTime;
	private String departureTime;
	private double ticketPrice;
	private int ticketAvailableQuantity;
	
	
	public void setTypeOfBus(String typeOfBus)
	{
		this.typeOfBus=typeOfBus;
	}
	
	public String getTypeOfBus()
	{
		return typeOfBus;
	}
	
	public void setBusId(int BusId)
	{
		this.BusId=BusId;
	}
	
	public void  setBusName(String BusName)
	{
		this.BusName=BusName;
	}
	
	public void setSource(String source)
	{
		this.source=source;
	}
	
	public void setDestination(String destination)
	{
		this.destination=destination;
	}
	
	public void setDate(String date)
	{
		this.date=date;
	}
	
	public void setArrivalTime(String arrivalTime)
	{
		this.arrivalTime=arrivalTime;
	}
	
	public void setDepartureTime(String departureTime)
	{
		this.departureTime=departureTime;
	}
	
	public void setTicketPrice(double ticketPrice)
	{
		this.ticketPrice=ticketPrice;
	}
	
	public void setTicketAvailableQuantity(int ticketAvailableQuantity)
	{
		this.ticketAvailableQuantity=ticketAvailableQuantity;
	}
	
	public int getBusId()
	{
		return BusId;
	}
	
	public String  getBusName()
	{
		return BusName;
	}
	
	public String getSource()
	{
		return source;
	}
	
	public String getDestination()
	{
		return destination;
	}
	
	public String getDate()
	{
		return date;
	}
	
	public String getArrivalTime()
	{
		return arrivalTime;
	}
	
	public String getDepartureTime()
	{
		return departureTime;
	}
	
	public double getTicketPrice()
	{
		return ticketPrice;
	}
	
	public int getTicketAvailableQuantity()
	{
		return ticketAvailableQuantity;
	}

	
	
}
	