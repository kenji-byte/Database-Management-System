
package classes ;
import java.lang.* ;

public class Payment extends Bus
{
		private double paidAmount;
		private String paymentPhnNumber;
		private String accountNumber;
		private String trxID; public Payment(){}
		public Payment(int BusId,String BusName,String source,String destination,String date,String arrivalTime,String departureTime,double ticketPrice,int ticketAvailableQuantity,double paidAmount,String paymentPhnNumber,String accountNumber,
		String trxID){
		super(BusId,BusName,source,destination,date,arrivalTime,departureTime,ticketPrice,ticketAvailableQuantity);
		this.paidAmount = paidAmount;
		this.paymentPhnNumber = paymentPhnNumber;
		this.accountNumber = accountNumber;
		this.trxID = trxID;
		}
		public void setPaidAmount(double paidAmount)
		{
		this.paidAmount = paidAmount;
		} public double getPaidAmount(){
		return paidAmount;
		}
		public void setPaymentPhnNumber(String paymentPhnNumber)
		{
		this.paymentPhnNumber = paymentPhnNumber; }
		public String getPaymentPhnNumber()
		{
		return paymentPhnNumber;
		}
		public void setAccountNumber(String accountNumber)
		{
		this.accountNumber = accountNumber; }
		public String getAccountNumber()
		{
		return accountNumber;
		}
		public void setTrxID(String trxID)
		{
		this.trxID = trxID;
		}
		public String getTrxID()
		{
		return trxID;
		}public void showDetails()
		{
		System.out.println("---------------------------");
		System.out.println("| Payment |");
		System.out.println("---------------------------");
		System.out.println("Bus ID:"+super.getBusId());
		System.out.println("Bus Name:"+super.getBusName());
		System.out.println("Bus Source:"+super.getSource());
		System.out.println("Bus Destination:"+super.getDestination());
		System.out.println("Date:"+super.getDate());
		System.out.println("Arrival Time:"+super.getArrivalTime());
		System.out.println("Departure Time:"+super.getDepartureTime());
		System.out.println("Ticket Price:"+super.getTicketPrice());
		System.out.println("Ticket Available Quantity:"+super.getTicketAvailableQuantity());
		System.out.println("Paid Amount is :"+paidAmount);
		System.out.println("Payment Phone Number :"+paymentPhnNumber);
		System.out.println("Account number is :"+accountNumber);
		System.out.println("Transaction Id is :"+trxID);}
		@Override
		public void showBusDetails() {
			// TODO Auto-generated method stub
			
		}

}

