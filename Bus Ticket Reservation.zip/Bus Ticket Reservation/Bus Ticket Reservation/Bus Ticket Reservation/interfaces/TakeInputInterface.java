package interfaces;
import java.lang .* ;


public interface TakeInputInterface{
    int takeIntInput(int min, int max);
    String takeStringInput();
}