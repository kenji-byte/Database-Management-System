package interfaces;
import classes.*;

public interface BusTicketOperations
{
	void addBusTicket(BusTicket t);
	void deleteBusTicket(BusTicket t);
	BusTicket getBusTicket(int BusId);
	void showAllBusTickets();
}