package interfaces;
import classes.Bus;
import java.lang.* ;

public interface BusOperations
{
	
	
	void bookTicket(Bus f);
	void cancelTicket(Bus f);
	Bus getTicket(int BusId);
	void showAllTicket(); 
}