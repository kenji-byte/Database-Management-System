package interfaces;

import java.lang.* ;


public interface ILogin
{
	public abstract void welcome();
	public abstract void systemLogin();
}