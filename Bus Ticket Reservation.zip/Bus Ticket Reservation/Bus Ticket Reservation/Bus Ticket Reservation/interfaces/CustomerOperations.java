package interfaces;
import classes.Customer;
import java.lang.* ;

public interface CustomerOperations
{
	void insertCustomer(Customer c);
	void removeCustomer(Customer c);
	void showAllCustomers();
	Customer getCustomer(int customerId);
}