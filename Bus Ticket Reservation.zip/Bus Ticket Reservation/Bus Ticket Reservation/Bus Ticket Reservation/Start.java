import java.lang.*;
import login.*;
import classes.*;
import interfaces.*;
import java.util.*;
import java.util.Scanner;
import fileio.FileReadWriteDemo;
import fileio.*;
import javax.swing.*;


public class Start
{
		public static void main(String args[])
		{
				Login logIn= new Login();
				logIn.welcome();
				logIn.systemLogin();	
                        
			
                JOptionPane.showMessageDialog(null,"User successfully logged-in","Welcome to Bus Ticket Reservation",JOptionPane.PLAIN_MESSAGE);
				Scanner sc = new Scanner(System.in);
				FileReadWriteDemo frwd = new FileReadWriteDemo();
				String n, bn;
				BusCount bc = new BusCount();


				System.out.println(	"                                         $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$");
				System.out.println("                                          //////////Bus Ticket Reservation /////////////");
				System.out.println("                                          $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$");

				boolean repeat = true;

				while(repeat)
				{
						System.out.println();
						System.out.println("Here are Some Options for You: \n");
						System.out.println();
						
						
						
						
						
						
						
						
						
						System.out.println("                            ||========================================||");
						System.out.println("                            ||1. Bus Ticket Management                ||");
						System.out.println("                            ||2. Customer Management                  ||");
						System.out.println("                            ||3. Customer Bus  Management.            ||");
						System.out.println("                            ||4. Payment.                             ||");
						System.out.println("                            ||5. Exit the Application                 ||");
						System.out.println("                            ||========================================||");
						
						System.out.println("              What do you want to do? : ");


						System.out.println("\n---------------------------");
						System.out.print("Enter Your Choice: ");
						int choice = sc.nextInt();
						System.out.println("---------------------------\n");
						
						
						
						
						
						
						
						
						
						
						switch(choice)
						{
								case 1:
											///First Class///

										System.out.println("			      ######################################");
										System.out.println("			      You Have Selected  Bus ticket Management");
										System.out.println("			      #####################################");
										System.out.println();
										System.out.println("Here are Some Options for You: \n");
										
										
										
										
										System.out.println("              ||========================================||");
										System.out.println("              || 1. Add Bus ticket                      ||");
										System.out.println("              || 2. Delete Bus ticket                   ||");
										System.out.println("              || 3. See all Bus tickets                 ||");
										System.out.println("              || 4. Go Back                             ||");
										System.out.println("              ||========================================||");

										System.out.println("\n---------------------------");
										System.out.print("Enter Your Option: ");
										int option1 = sc.nextInt();
										System.out.println("---------------------------\n");

										switch(option1)
										{
												case 1:

														System.out.println("                  *********************************");
														System.out.println("                  You Have Selected Add Bus ticket.");
														System.out.println("                  *********************************");
														System.out.println();
														System.out.println("Enter Type Of Bus: ");
														String typeOfBus = sc.next();
														System.out.println("Enter Bus Id: ");
														int BusId = sc.nextInt();
														System.out.println("Enter Bus Name: ");
														String BusName = sc.next();
														System.out.println("Enter Bus Source:" );
														String source= sc.next();
														System.out.println("Enter Bus Destination:");
														String destination= sc.next();
														System.out.println("Enter Date:");
														String date= sc.next();
														System.out.println("Enter Arrival Time:");
														String arrivalTime= sc.next();
														System.out.println("Enter Departure Time:");
														String departureTime= sc.next();
														System.out.println("Enter Ticket Price: ");
														double ticketPrice = sc.nextDouble();
														System.out.println("Enter Ticket Available Quantity:");
														int ticketAvailableQuantity= sc.nextInt();
																
														BusTicket t=new BusTicket();
														t.setTypeOfBus( typeOfBus);
														t.setBusId( BusId);
														t.setBusName( BusName);
														t.setSource(source);
														t.setDestination(destination);
														t.setDate( date);
														t.setArrivalTime(arrivalTime);
														t.setDepartureTime( departureTime);
														t.setTicketPrice(ticketPrice);
														t.setTicketAvailableQuantity(ticketAvailableQuantity);
												   
														bc.addTicket(t);
														


														break;

												case 2:

													   System.out.println("					*********************************");
													   System.out.println("					You Have Selected Delete Bus ticket.");
													   System.out.println("					*********************************");
													   System.out.print("Enter  Bus Id: ");
													   bc.cancelTicket(bc.getTicket(sc.nextInt()));
														break;



												case 3:

													  System.out.println("					************************************");
													  System.out.println("					You Have Selected see All Bus tickets");
													  System.out.println("					************************************");
													  System.out.println();
													  bc.showAlBusTickets();

														break;

												case 4:

													  System.out.println("					*********************");
													  System.out.println("					Going Back...........");
													  System.out.println("					*********************");
														repeat= false;
														System.out.println();
														break;

												default:

													  System.out.println("					*********************");
													  System.out.println("					Invalid Option.......");
													  System.out.println("					*********************");
													  System.out.println();

													break;
										}
								

								break;
								
								
								 
								case 2:
											///Customer Management///
											
										System.out.println("						#####################################");
										System.out.println("						You Have Selected Customer Management");
										System.out.println("						#####################################");
										System.out.println();
										
										System.out.println("\tCustomer Management Options are: \n");
										System.out.println("            ||========================================||");
										System.out.println("            ||1. Insert New Customer                  ||");
										System.out.println("            ||2. Remove Customer                      ||");
										System.out.println("            ||3. Show All Customers                   ||");
										System.out.println("            ||4. Go Back                              ||");
										System.out.println("            ||========================================||");
										System.out.println("\n---------------------------");
										System.out.print("Enter Your Option: ");
										int option2 = sc.nextInt();
										System.out.println("---------------------------\n");
										
										switch(option2)
										{
											case 1:
												
												System.out.println("                       *********************************");
												System.out.println("                       You Have Selected Insert Customer");
												System.out.println("                       *********************************");
												System.out.println();
												
												System.out.print("Enter Customer Name: ");
												String customerName1 = sc.next();
												System.out.print("Enter Customer Id: ");
												int customerId1=sc.nextInt();
												
												
												Customer c1 = new Customer();
												c1.setCustomerName( customerName1);
												c1.setCustomerId(customerId1);
				
												bc.insertCustomer(c1);
												
												break;
												
											case 2:
												
												System.out.println("                      *********************************");
												System.out.println("                      You Have Selected Remove Customer");
												System.out.println("                      *********************************");
												System.out.println();
												
												System.out.print("Enter Customer Id: ");
												int customerId2 = sc.nextInt();
												bc.removeCustomer(bc.getCustomer(customerId2));
									
												
												break;
												
											
												
											case 3:
												
												System.out.println("                     ************************************");
												System.out.println("                     You Have Selected Show All Customers");
												System.out.println("                     ************************************");
												System.out.println();
												bc.showAllCustomers();
												
												break;
												
											case 4:
												
												System.out.println("                      *********************");
												System.out.println("                      Going Back...........");
												System.out.println("                      *********************");
												repeat = false;
												System.out.println();
												break;
												
											default:
												
												System.out.println("                      *********************");
												System.out.println("                      Invalid Option.......");
												System.out.println("                      *********************");
												System.out.println();
												
												break;
										}
									
				
									break;
									
									case 3:
											///Customer Ticket management///
										System.out.println("                         ######################################");
										System.out.println("						 You Have Selected Customer Ticket Management.");
										System.out.println("						 ######################################");
										System.out.println();
										
										System.out.println("Customer Bus Management options are:");
										
										System.out.println("                      ||========================================||");
										System.out.println("                      ||1. Book a Bus ticket for a customer     ||");
                                        System.out.println("                      ||2. Cancel a Bus ticket for a customer   ||");
										System.out.println("                      ||3. Show all  Bus ticket                 ||");
										System.out.println("                      ||4. Go Back                              ||");
								        System.out.println("                      ||========================================||");
								
										System.out.println("\n---------------------------");
										System.out.print("Enter Your Option: ");
										int option3 = sc.nextInt();
										System.out.println("---------------------------\n");

										switch(option3)
										{
										case 1:

												Bus b = null;
												
												System.out.println("There are 3 types of Bus: ");
												System.out.println("              ||========================================||");
												System.out.println("              || 1. First Class Bus                     ||");
												System.out.println("              || 2. Business Class Bus                  ||");
												System.out.println("              || 3. Economy Class Bus                   ||");
												System.out.println("              || 4.Go back                              ||");
												System.out.println("              ||========================================||");
												System.out.print("What do you want to do? : ");
												
												int type = sc.nextInt();
												
												System.out.println("Enter Type Of Bus: ");
												String typeOfBus = sc.next();
												System.out.println("Enter Bus Id: ");
												int BusId1 = sc.nextInt();
												System.out.println("Enter Bus Name: ");
												String BusName = sc.next();
												System.out.println("Bus Source:");
												String source=sc.next();
												System.out.println("Bus Destination:");
												String destination=sc.next();
												System.out.println("Date:");
												String date=sc.next();
												System.out.println("Arrival Time:");
												String arrivalTime=sc.next();
												System.out.println("Departure Time:");
												String departureTime=sc.next();
												System.out.println("Ticket Price:");
												double ticketPrice=sc.nextDouble();
												System.out.println("Ticket Available Quantity:");
												int ticketAvailableQuantity=sc.nextInt();
												if(type==1)
												{
													FirstClass fc1 = new FirstClass();
													fc1.setTypeOfBus(typeOfBus);
													fc1.setBusId(BusId1);
													fc1.setBusName(BusName);
													fc1.setSource(source);
													fc1.setDestination(destination);
													fc1.setDate(date);
													fc1.setArrivalTime(arrivalTime);
													fc1.setDepartureTime(departureTime);
													fc1.setTicketPrice(ticketPrice);
													fc1.setTicketAvailableQuantity(ticketAvailableQuantity);
													
													b=fc1;
														
												}
												
												else if(type==2)
												{
													BusinessAcClass bc1 = new BusinessAcClass();
													bc1.setTypeOfBus(typeOfBus);
													bc1.setBusId(BusId1);
													bc1.setBusName(BusName);
													bc1.setSource(source);
													bc1.setDestination(destination);
													bc1.setDate(date);
													bc1.setArrivalTime(arrivalTime);
													bc1.setDepartureTime(departureTime);
													bc1.setTicketPrice(ticketPrice);
													bc1.setTicketAvailableQuantity(ticketAvailableQuantity);
													
													b=bc1;
												}
												
												else if(type==3)
												{
													EconomyClass ec1 = new EconomyClass();
													ec1.setTypeOfBus(typeOfBus);
													ec1.setBusId(BusId1);
													ec1.setBusName(BusName);
													ec1.setSource(source);
													ec1.setDestination(destination);
													ec1.setDate(date);
													ec1.setArrivalTime(arrivalTime);
													ec1.setDepartureTime(departureTime);
													ec1.setTicketPrice(ticketPrice);
													ec1.setTicketAvailableQuantity(ticketAvailableQuantity);
													
													b=ec1;
												}
												
												else if(type==4)
												{
													System.out.print("Going Back . . .");
												}
												
												else
												{
													System.out.println("Invalid Input");
												}
												if(b!=null)
												{
													
													System.out.print("Enter Customer Id: ");
													int customerId= sc.nextInt();
													
					
													bc.getCustomer(customerId).bookTicket(b);
												}
												
												break;
												
					
										case 2:	
												
												System.out.print("Enter Customer Id: ");
												int customerId3=sc.nextInt();
												System.out.print("Enter  Bus Id: ");
												int BusId3=sc.nextInt();
												bc.getCustomer(customerId3).cancelTicket(bc.getCustomer(customerId3).getTicket(BusId3));
					
												break;
												
										
												
										case 3:
												System.out.print("Enter Customer Id: ");
												int customerId4=sc.nextInt();
												
												
												bc.getCustomer(customerId4).showAllTicket();
					
												break;
												
										case 4:
				
												System.out.println("Going Back . . .");
												break;
												
											default:
											
												System.out.println("Invalid Input");
												break;
										}
								
										
								break;
												

								case 4:
									
										System.out.println();
										System.out.println("						||$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$||");
										System.out.println("						||--------------Payment-------------- ||");
										System.out.println("						||$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$||");
										System.out.println();
										
										System.out.println("Choose a payment option:");
										System.out.println("              ||========================================||");
										System.out.println("              ||1.Credit card.                          ||");
										System.out.println("              ||2.Debit card.                           ||") ;
										System.out.println("              ||3.Rocket/Bkash number.                  ||");
										System.out.println("              ||4.Exit.                                 ||");
										System.out.println("              ||========================================||");
										
										
										
										System.out.println("\n---------------------------");
										System.out.print("Enter Your Option: ");
										int option4 = sc.nextInt();
										System.out.println("---------------------------\n");
										switch(option4)
										{
											case 1:
												System.out.print("Enter Credit Card number: ");
												int op = sc.nextInt();
												System.out.print("Enter Pin: ");
												int opt = sc.nextInt();
												System.out.println("Enter Amount: ");
												int money =sc.nextInt();
												System.out.println("Verifying.....");
												System.out.println("Payment Successful!");
												System.out.println("Thank you.");
												System.exit(0);
											case 2:
												System.out.print("Enter Debit Card number: ");
												System.out.print("Enter Pin: ");
												int opti = sc.nextInt();
												System.out.println("Verifying.....");
												System.out.println("Payment Successful!");
												System.out.println("Thank you.");
												System.exit(0);
											case 3:
												System.out.print("Enter Rocket/Bkash number: ");
												int o = sc.nextInt();
												System.out.print("Enter Pin: ");
												int option= sc.nextInt();
												System.out.println("Verifying.....");
												System.out.println("Payment Successful!");
												System.out.println("Thank you.");
												System.exit(0);
											case 4:
												System.exit(0); 
												break;
										}
										
										break ;
	
								case 5:

										System.out.println("                              ###################################");
										System.out.println("                              Thank You for Using Our Application");
										System.out.println("                              #################################");
										System.out.println();

										repeat = false;

										break;

								default:

										System.out.println("                              ######################");
										System.out.println("                              Invalid Selection.....");
										System.out.println("                              ######################");
										System.out.println();

										break;
										
						}
				}
		}
		
}	
																	










