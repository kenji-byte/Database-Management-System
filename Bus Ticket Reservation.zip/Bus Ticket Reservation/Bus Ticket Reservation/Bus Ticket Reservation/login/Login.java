package login;

import interfaces.ILogin;
import java.util.Scanner;

import java.lang.*;
import javax.swing.*;

public class Login implements ILogin{
	public Login(){}
	
	public void welcome(){
	System.out.println();		
	//System.out.println("\t\t****Welcome to  Bus Ticket reservation System****");
	//JOptionPane.showMessageDialog(null,"Welcome to Bus Ticket Reservation","Messege",JOptionPane.PLAIN_MESSAGE);
	System.out.println();

	}
	
	
	
	public void systemLogin(){
	Scanner scan = new Scanner(System.in);
	JOptionPane.showMessageDialog(null," Press Enter to Continue This System","Welcome to Bus Ticket Reservation",JOptionPane.PLAIN_MESSAGE);
	System.out.println();
	
	int count = 0;
         while (count <= 1) 
            {
                Scanner input = new Scanner(System.in);

                String username;
                String password;

               // System.out.print("\t\tEnter Username: ");

                username = JOptionPane.showInputDialog("Enter Username:");
                //username = input.next();

                //System.out.print("\t\tEnter Password: ");
				
                password = JOptionPane.showInputDialog("Enter Password:");
                if ("java".equals(username) && "java".equals(password)) 
                {
                  
					 
                } 
                else 
                {
                    System.out.println("\t\tSorry! You Enter Invalid Username or Password. Please Try again");
                    System.exit(0);
                }
                count++;
                break;

            }	
	}
	
	
	
}